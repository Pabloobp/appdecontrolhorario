import 'dart:io';
import 'dart:convert';

void main() {
  final file = File('lib/main.dart');
  
  // Read as bytes and decode to avoid Invalid UTF8 exceptions stopping the string
  List<int> bytes = file.readAsBytesSync();
  String content = utf8.decode(bytes, allowMalformed: true);
  
  content = content.replaceAll('Ã¡', '�');
  content = content.replaceAll('Ã©', '�');
  content = content.replaceAll('Ã³', '�');
  content = content.replaceAll('Ãº', '�');
  content = content.replaceAll('Ã±', '�');
  content = content.replaceAll('Â¿', '�');
  content = content.replaceAll('biometrÃ�a', 'biometr�a');
  content = content.replaceAll('DÃ�a', 'D�a');
  content = content.replaceAll('dÃ�a', 'd�a');
  content = content.replaceAll('AÃ±adir', 'A�adir');
  content = content.replaceAll('GestiÃ³n', 'Gesti�n');
  
  // Also clean up any single ones remaining just in case
  content = content.replaceAll('á', '�');
  content = content.replaceAll('é', '�');
  content = content.replaceAll('ó', '�');
  content = content.replaceAll('ú', '�');
  content = content.replaceAll('ñ', '�');
  content = content.replaceAll('ÿ', '�');
  
  file.writeAsStringSync(content);
  print('main.dart cleaned!');
}
