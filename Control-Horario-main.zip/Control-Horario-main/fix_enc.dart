import 'dart:io';

void main() {
  final file = File('lib/main.dart');
  String content = file.readAsStringSync();
  
  content = content.replaceAll('á', '�');
  content = content.replaceAll('é', '�');
  content = content.replaceAll('ó', '�');
  content = content.replaceAll('ú', '�');
  content = content.replaceAll('ñ', '�');
  content = content.replaceAll('biometr�a', 'biometr�a');
  content = content.replaceAll('D�a', 'D�a');
  content = content.replaceAll('d�a', 'd�a');
  content = content.replaceAll('Añadir', 'A�adir');
  content = content.replaceAll('Gestión', 'Gesti�n');
  
  file.writeAsStringSync(content);
  print('main.dart fixed');
  
  final file2 = File('lib/gestion_page.dart');
  if (file2.existsSync()) {
    String content2 = file2.readAsStringSync();
    content2 = content2.replaceAll('á', '�');
    content2 = content2.replaceAll('é', '�');
    content2 = content2.replaceAll('ó', '�');
    content2 = content2.replaceAll('ú', '�');
    content2 = content2.replaceAll('ñ', '�');
    file2.writeAsStringSync(content2);
    print('gestion_page.dart fixed');
  }
}
