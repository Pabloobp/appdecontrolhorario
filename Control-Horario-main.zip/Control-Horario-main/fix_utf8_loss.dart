import 'dart:io';

void main() {
  final file = File('lib/main.dart');
  String content = file.readAsStringSync();

  final map = {
    'Sesi�n': 'Sesi�n',
    'sesi�n': 'sesi�n',
    'electr�nico': 'electr�nico',
    'Contrase�a': 'Contrase�a',
    'contrase�a': 'contrase�a',
    '�Olvidaste': '�Olvidaste',
    'r�pido': 'r�pido',
    'inv�lido': 'inv�lido',
    'Funci�n': 'Funci�n',
    'recuperaci�n': 'recuperaci�n',
    'pr�xima': 'pr�xima',
    'versi�n': 'versi�n',
    'Versi�n': 'Versi�n',
    'biometr�a': 'biometr�a',
    'Men�': 'Men�',
    'Oc�ano': 'Oc�ano',
    'b�squeda': 'b�squeda',
    'Reuni�n': 'Reuni�n',
    'Revisi�n': 'Revisi�n',
    'Ecol�gico': 'Ecol�gico',
    'Cl�sico': 'Cl�sico',
    'C�lido': 'C�lido',
    'pr�cticas': 'pr�cticas',
    'A�n': 'A�n',
    'D�a': 'D�a',
    'd�a': 'd�a',
    'A�adir': 'A�adir',
    'Gesti�n': 'Gesti�n',
    'A�o': 'A�o',
    'a�o': 'a�o',
    'Mi�': 'Mi�',
  };

  map.forEach((bad, good) {
    content = content.replaceAll(bad, good);
  });
  
  file.writeAsStringSync(content);
  print('main.dart repaired');

  final file2 = File('lib/gestion_page.dart');
  if (file2.existsSync()) {
    String content2 = file2.readAsStringSync();
    map.forEach((bad, good) {
      content2 = content2.replaceAll(bad, good);
    });
    // Add any specific to gestion_page
    content2 = content2.replaceAll('Luc�a', 'Luc�a');
    content2 = content2.replaceAll('Gesti�n', 'Gesti�n');
    content2 = content2.replaceAll('Mi�', 'Mi�');
    file2.writeAsStringSync(content2);
    print('gestion_page.dart repaired');
  }
}
